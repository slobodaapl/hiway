use loom::{
    sync::{mpsc, Arc, Condvar, Mutex, RwLock},
    thread,
};

type Batch = Arc<[u8]>;

fn batch(first: u8, second: u8) -> Batch {
    let values: std::sync::Arc<[u8]> = std::sync::Arc::new([first, second]);
    Arc::from_std(values)
}

#[derive(Clone)]
struct ModelBus {
    transforms: Arc<RwLock<Vec<u8>>>,
    ready_tx: mpsc::Sender<Batch>,
    ready_rx: Arc<Mutex<mpsc::Receiver<Batch>>>,
    // Tokio owns broadcast fan-out, capacity, and lag. One append represents one whole send.
    committed: Arc<Mutex<Vec<Batch>>>,
}

impl ModelBus {
    fn new() -> Self {
        let (ready_tx, ready_rx) = mpsc::channel();
        Self {
            transforms: Arc::new(RwLock::new(vec![1])),
            ready_tx,
            ready_rx: Arc::new(Mutex::new(ready_rx)),
            committed: Arc::new(Mutex::new(Vec::new())),
        }
    }

    fn prepare(&self, batch: Batch) {
        self.ready_tx.send(batch).unwrap();
    }

    fn tick(&self) -> bool {
        let batch = {
            let Ok(receiver) = self.ready_rx.try_lock() else {
                return false;
            };
            receiver.try_recv().ok()
        };
        let Some(batch) = batch else {
            return false;
        };
        self.committed.lock().unwrap().push(batch);
        true
    }

    fn committed(&self) -> Vec<Batch> {
        self.committed.lock().unwrap().clone()
    }

    fn subscribe(&self) -> ModelSubscription {
        ModelSubscription {
            committed: self.committed.clone(),
            next_batch: 0,
            current: None,
            index: 0,
        }
    }
}

struct ModelSubscription {
    committed: Arc<Mutex<Vec<Batch>>>,
    next_batch: usize,
    current: Option<Batch>,
    index: usize,
}

impl ModelSubscription {
    fn recv(&mut self) -> Option<u8> {
        loop {
            if let Some(batch) = &self.current {
                if let Some(token) = batch.get(self.index) {
                    self.index += 1;
                    return Some(*token);
                }
            }

            self.current = None;
            self.index = 0;
            let batch = self.committed.lock().unwrap().get(self.next_batch).cloned();
            let batch = batch?;
            self.next_batch += 1;
            self.current = Some(batch);
        }
    }

    fn drain(&mut self) -> Vec<u8> {
        let mut tokens = Vec::new();
        while let Some(token) = self.recv() {
            tokens.push(token);
        }
        tokens
    }
}

#[test]
fn snapshot_releases_registry_before_user_work() {
    loom::model(|| {
        let bus = ModelBus::new();
        let snapshot_ready = Arc::new((Mutex::new(false), Condvar::new()));
        let user_gate = Arc::new((Mutex::new(false), Condvar::new()));

        let publisher_bus = bus.clone();
        let publisher_ready = snapshot_ready.clone();
        let publisher_gate = user_gate.clone();
        let publisher = thread::spawn(move || {
            let snapshot = {
                let stages = publisher_bus.transforms.read().unwrap();
                stages.clone()
            };

            let (ready, changed) = &*publisher_ready;
            let mut ready = ready.lock().unwrap();
            *ready = true;
            changed.notify_one();
            drop(ready);

            let (gate, changed) = &*publisher_gate;
            let mut gate = gate.lock().unwrap();
            while !*gate {
                gate = changed.wait(gate).unwrap();
            }
            snapshot
        });

        let registrar_bus = bus.clone();
        let registrar_ready = snapshot_ready.clone();
        let registrar_gate = user_gate.clone();
        let registrar = thread::spawn(move || {
            let (ready, changed) = &*registrar_ready;
            let mut ready = ready.lock().unwrap();
            while !*ready {
                ready = changed.wait(ready).unwrap();
            }
            drop(ready);

            registrar_bus.transforms.write().unwrap().push(2);

            let (gate, changed) = &*registrar_gate;
            let mut gate = gate.lock().unwrap();
            *gate = true;
            changed.notify_one();
        });

        let snapshot = publisher.join().unwrap();
        registrar.join().unwrap();

        assert_eq!(snapshot, vec![1]);
        assert_eq!(&*bus.transforms.read().unwrap(), &vec![1, 2]);
    });
}

#[test]
fn ready_queue_uses_preparation_completion_order() {
    loom::model(|| {
        let bus = ModelBus::new();
        let slow_gate = Arc::new((Mutex::new((false, false)), Condvar::new()));

        let first_bus = bus.clone();
        let first_gate = slow_gate.clone();
        let slow = thread::spawn(move || {
            let (state, changed) = &*first_gate;
            let mut state = state.lock().unwrap();
            state.0 = true;
            changed.notify_one();
            while !state.1 {
                state = changed.wait(state).unwrap();
            }
            drop(state);
            first_bus.prepare(batch(1, 11));
        });

        let (state, changed) = &*slow_gate;
        let mut state = state.lock().unwrap();
        while !state.0 {
            state = changed.wait(state).unwrap();
        }
        drop(state);

        let fast_bus = bus.clone();
        let fast_gate = slow_gate.clone();
        let fast = thread::spawn(move || {
            fast_bus.prepare(batch(2, 22));
            let (state, changed) = &*fast_gate;
            let mut state = state.lock().unwrap();
            state.1 = true;
            changed.notify_one();
        });

        fast.join().unwrap();
        slow.join().unwrap();

        assert!(bus.tick());
        assert!(bus.tick());
        assert!(!bus.tick());
        let committed = bus.committed();
        assert_eq!(
            committed.iter().map(|batch| batch[0]).collect::<Vec<_>>(),
            vec![2, 1]
        );
    });
}

#[test]
fn concurrent_tickers_commit_each_prepared_batch_once() {
    loom::model(|| {
        let bus = ModelBus::new();
        bus.prepare(batch(1, 11));
        bus.prepare(batch(2, 22));

        let first_bus = bus.clone();
        let first = thread::spawn(move || first_bus.tick());
        let second_bus = bus.clone();
        let second = thread::spawn(move || second_bus.tick());
        first.join().unwrap();
        second.join().unwrap();
        let _ = bus.tick();
        let _ = bus.tick();
        assert!(!bus.tick());

        let committed = bus.committed();
        assert_eq!(committed.len(), 2);
        let mut seen_first = 0;
        let mut seen_second = 0;
        for batch in &committed {
            match batch.as_ref() {
                [1, 11] => seen_first += 1,
                [2, 22] => seen_second += 1,
                other => panic!("interleaved or unknown batch: {other:?}"),
            }
        }
        assert_eq!((seen_first, seen_second), (1, 1));
    });
}

#[test]
fn tick_is_nonblocking_and_commits_one_batch_at_a_time() {
    loom::model(|| {
        let bus = ModelBus::new();
        assert!(!bus.tick());

        let held = Arc::new((Mutex::new(false), Condvar::new()));
        let release = Arc::new((Mutex::new(false), Condvar::new()));
        let holder_bus = bus.clone();
        let holder_held = held.clone();
        let holder_release = release.clone();
        let holder = thread::spawn(move || {
            let receiver = holder_bus.ready_rx.lock().unwrap();

            let (started, changed) = &*holder_held;
            let mut started = started.lock().unwrap();
            *started = true;
            changed.notify_one();
            drop(started);

            let (released, changed) = &*holder_release;
            let mut released = released.lock().unwrap();
            while !*released {
                released = changed.wait(released).unwrap();
            }
            drop(released);
            drop(receiver);
        });

        let (started, changed) = &*held;
        let mut started = started.lock().unwrap();
        while !*started {
            started = changed.wait(started).unwrap();
        }
        drop(started);

        assert!(!bus.tick());

        let (released, changed) = &*release;
        let mut released = released.lock().unwrap();
        *released = true;
        changed.notify_one();
        drop(released);
        holder.join().unwrap();

        bus.prepare(batch(1, 11));
        bus.prepare(batch(2, 22));
        assert!(bus.tick());
        assert_eq!(bus.committed().len(), 1);
        assert!(bus.tick());
        assert_eq!(bus.committed().len(), 2);
        assert!(!bus.tick());
        assert_eq!(bus.committed().len(), 2);
    });
}

#[test]
fn subscriber_drains_each_batch_before_the_next_batch() {
    loom::model(|| {
        let bus = ModelBus::new();
        let mut subscriber = bus.subscribe();
        bus.prepare(batch(1, 11));
        assert!(bus.tick());
        assert_eq!(subscriber.recv(), Some(1));

        bus.prepare(batch(2, 22));
        assert!(bus.tick());
        assert_eq!(subscriber.drain(), vec![11, 2, 22]);
    });
}

#[test]
fn subscribers_have_identical_order_and_independent_cursors() {
    loom::model(|| {
        let bus = ModelBus::new();
        let mut first = bus.subscribe();
        let mut second = bus.subscribe();
        bus.prepare(batch(1, 11));
        bus.prepare(batch(2, 22));
        assert!(bus.tick());
        assert!(bus.tick());

        assert_eq!(first.recv(), Some(1));
        assert_eq!(second.recv(), Some(1));
        assert_eq!(second.drain(), vec![11, 2, 22]);
        assert_eq!(first.drain(), vec![11, 2, 22]);
    });
}
